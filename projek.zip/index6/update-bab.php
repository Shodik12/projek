<?php include "./../koneksi.php";?>

<?php 
 
  $id = $_POST['id'];
$bab = $_POST['bab'];

mysqli_query($koneksi,"UPDATE bab6 SET bab='$bab' WHERE id='$id'");
 
header("location:index-bab.php?sukses=edit");
?>